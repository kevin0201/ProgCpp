
/**
* \file Ouvrage.h
* \brief Fichier d'en-tête des methodes et attributs de classe Ouvrage
* \author Kevin BAMOUNI
* \version 1.0
* \date 19/02/2016
*/

/**
* \class Ouvrage
* \brief Classe implantant le concept d'ouvrage, de publication...
* La classe Pile permet d'implanter le concept de publication elle possède donc un quelques caractéristiques propres aux publications…
* Attributs: std::string m_auteurs; Nom de l'auteur de la publication
*	std::string m_editeur; Nom de l'éditeur de la publication
*	std::string m_ville; Nom de la ville d'origine de la publication
*	std::string m_titre; Titre de la publication
*	int m_annee; Année de publication
*	std::string m_identifiant; Identifiant unique de la publication
*
* Note: les informations liées à l'enregistrement d'un ouvrage sont soumis à validation par des fonctions du fichier validationFormat.cpp
*
*/

#ifndef OUVRAGE_H_
#define OUVRAGE_H_
#include <string>
namespace tp
{

class Ouvrage {

public:
	Ouvrage(const std::string& p_auteurs,
			const std::string& p_titre,
			const std::string& p_identifiant,
			int  p_annee,
			const std::string& p_ville,
			const std::string& p_editeur);

	const std::string& reqAuteurs() const;
	const std::string& reqEditeur() const;
	const std::string& reqIdentifiant() const;
	int reqAnnee() const;
	const std::string& reqTitre() const;
	const std::string& reqVille() const;
	const std::string& reqOuvrageFormate() const;
	void asgAuteurs(const std::string& p_auteurs);
	void asgAnnee(int annee);
	void asgEditeur(const std::string& editeur);
	void asgIdentifiant(const std::string& identifiant);
	void asgTitre(const std::string& titre);
	void asgVille(const std::string& ville);

private:
	std::string m_auteurs;
	std::string m_editeur;
	std::string m_ville;
	std::string m_titre;
	int m_annee;
	std::string m_identifiant;
};

}
#endif /* OUVRAGE_H_ */
