
/**
* \file gestionReferences.cpp
* \brief Fichier d'en-tête des fonctions de validations des formats de nom et de code ISSN et ISBN
* \author Kevin BAMOUNI
* \version 1.0
* \date 19/02/2016
*/

#include <iostream>
#include <sstream>
#include <string>
#include "Ouvrage.h"
#include "validationFormat.h"

using namespace std;
using namespace tp;
using namespace util;


int main() {
	//déclartion des variables
	char choixUsager;
	string m_auteurs;
	string m_editeur;
	string m_ville;
	string m_titre;
	string m_identifiant;
	string af;
	int m_annee(0);
	bool teste_m_auteurs;
	bool teste_m_editeurs;
	bool teste_m_ville;
	bool teste_m_titre;
	bool teste_m_identifiant;
	choixUsager='y';

	cout << "CREER un ouvrage" << endl; // prints !!!Hello World!!!

	do{//boucle de contrôle du format de la chaîne représentant le nom de l'auteur saisie; demande de saisie tant que le format est invalide
	cout << "SAISIR LE(S) AUTEUR(S) :" << endl;
	cin >> m_auteurs;
	teste_m_auteurs=validerFormatNom(m_auteurs);
	}while(teste_m_auteurs==false);

	do{//boucle de contrôle du format de la chaîne représentant le nom de l'éditeur saisie; demande de saisie tant que le format est invalide
	cout << "SAISIR LE(S) EDITEUR(S) :" << endl;
	cin >> m_editeur;
	teste_m_editeurs=validerFormatNom(m_editeur);
	}while(teste_m_editeurs==false);

	do{//boucle de contrôle du format de la chaîne représentant le nom de la ville d'origine de l'ouvrage saisie; demande de saisie tant que le format est invalide
	cout << "SAISIR LE(S) VILLE(S) :" << endl;
	cin >> m_ville;
	teste_m_ville=validerFormatNom(m_ville);
	}while(teste_m_ville==false);

	do{//boucle de contrôle du format de la chaîne représentant le titre de l'ouvrage saisie; demande de saisie tant que le format est invalide
	cout << "SAISIR LE TITRE :" << endl;
	cin >> m_titre;
	teste_m_titre=validerFormatNom(m_titre);
	}while(teste_m_titre==false);

	do{//boucle de contrôle du format de la chaîne représentant l'année de parution de l'ouvrage saisie; demande de saisie tant que le format est invalide (année supérieure à 0)
	cout << "SAISIR L'ANNEE :" << endl;
	cin >> m_annee;
	}while(m_annee<= 0);

	do{//boucle de contrôle du format de la chaîne représentant l'identifiant ISBN de l'ouvrage saisie; demande de saisie tant que le format est invalide
	cout << "SAISIR L' IDENTIFIANT :" << endl;
	cin >> m_identifiant;
	teste_m_identifiant=validerCodeIsbn(m_identifiant);
	}while(teste_m_identifiant==false);

	//Instantiation de l'objet l'ouvrage de la classe Ouvrage
	Ouvrage nouvelOuvrage( m_auteurs ,m_titre , m_identifiant,m_annee,m_ville,m_editeur );

	//confirmation de création de l'ouvrage; interaction du prgramme avec l'utilisateur (externe au programme)
	cout << "VOUS VENEZ DE CREER L'OUVRAGE SUIVANT:" << endl;
	cout <<nouvelOuvrage.reqOuvrageFormate()<<endl;//Affichage à la sortie standard des informations sur l'objet ouvrage entrée
	while(choixUsager=='y')
	{

		do
		{//Choix de modification ou nom du nom de l'auteur.
			cout << "VOULEZ VOUS MODIFIER LE(S) AUTEUR(S) DE L'OUVRAGE QUE VOUS VENEZ DE CREER?" << endl;
			cout << "TAPER (y) pour OUI // TAPER (n) pour NON" << endl;
			cin >> choixUsager;
		}while(choixUsager!='y' && choixUsager!='n');
		//si le choix est positif; récupération du nouveau nom de l'auteur en entrée standard
		if (choixUsager=='y')
		{
			do
			{//Reprise de la saisie tant que le format du nom de l'auteur n'est pas validé
			cout << "SAISIR LE(S) AUTEUR(S) :" << endl;
			cin >> m_auteurs;
			teste_m_auteurs=validerFormatNom(m_auteurs);//Test de la conformité du nom de l'auteur aux exigences de la fonction
			}while(teste_m_auteurs==false);

			nouvelOuvrage.asgAuteurs(m_auteurs);//Utilisation de la fonction modificatrice de l'objet pour accéder à l'attibut (privé)
		}

	}

	return 0;
}
