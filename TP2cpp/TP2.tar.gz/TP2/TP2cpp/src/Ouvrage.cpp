
/**
* \file Ouvrage.cpp
* \brief Fichier des codes des différentes méthodes de la classee Ouvrage
* \author Kevin BAMOUNI
* \version 1.0
* \date 19/02/2016
*/

#include "Ouvrage.h"
#include <string>
#include <sstream>
using namespace std;
namespace tp
{

/**
* \brief Cette fonction est le constructeur de la classe Ouvrage
* \param[in] std::string m_auteurs; Nom de l'auteur de la publication
*	std::string m_editeur; Nom de l'éditeur de la publication
*	std::string m_ville; Nom de la ville d'origine de la publication
*	std::string m_titre; Titre de la publication
*	int m_annee; Année de publication
*	std::string m_identifiant; Identifiant unique de la publication
* \pre Tous les paramètres sont soumis à contrôle par un ensemble de fontions validationFormat.cpp
* \post La cré un objet ouvrage aves ses attributs et ses méthodes
*/
Ouvrage::Ouvrage(const std::string& p_auteurs,
		const std::string& p_titre,
		const std::string& p_identifiant,
		int  p_annee,
		const std::string& p_ville,
		const std::string& p_editeur)
{
	 	 m_auteurs=p_auteurs;
		 m_editeur=p_editeur;
		 m_ville=p_ville;
		 m_titre=p_titre;
		 m_annee=p_annee;
		 m_identifiant=p_identifiant;
}

/**
* \brief Cette fonction est une fonction d'accès à la valeur d'un attibut privé
* \param[in] aucun
* \pre
* \post La fonction retourne l'attribut m_annee
*/
int Ouvrage::reqAnnee() const {
	return m_annee;
}
/**
* \brief Cette fonction est une fonction d'accès à la valeur d'un attibut privé
* \param[in] aucun
* \pre
* \post La fonction retourne l'attribut m_auteurs
*/
const std::string& Ouvrage::reqAuteurs() const {
	return m_auteurs;
}
/**
* \brief Cette fonction est une fonction d'accès à la valeur d'un attibut privé
* \param[in] aucun
* \pre
* \post La fonction retourne l'attribut m_editeur
*/
const std::string& Ouvrage::reqEditeur() const {
	return m_editeur;
}
/**
* \brief Cette fonction est une fonction d'accès à la valeur d'un attibut privé
* \param[in] aucun
* \pre
* \post La fonction retourne l'attribut m_identifiant
*/
const std::string& Ouvrage::reqIdentifiant() const {
	return m_identifiant;
}
/**
* \brief Cette fonction est une fonction d'accès à la valeur d'un attibut privé
* \param[in] aucun
* \pre
* \post La fonction retourne l'attribut m_titre
*/
const std::string& Ouvrage::reqTitre() const {
	return m_titre;
}
/**
* \brief Cette fonction est une fonction d'accès à la valeur d'un attibut privé
* \param[in] aucun
* \pre
* \post La fonction retourne l'attribut m_ville
*/
const std::string& Ouvrage::reqVille() const {
	return m_ville;
}
/**
* \brief Cette fonction est une fonction de modification d'un attibut privé
* \param[in] aucun
* \pre
* \post La fonction retourne l'attribut m_auteurs
*/
void Ouvrage::asgAuteurs(const std::string& p_auteurs) {
	m_auteurs = p_auteurs;
}
/**
* \brief Cette fonction est une fonction de modification d'un attibut privé
* \param[in] aucun
* \pre
* \post La fonction retourne l'attribut m_auteurs
*/
void Ouvrage::asgAnnee(int annee) {
	m_annee = annee;
}
/**
* \brief Cette fonction est une fonction de modification d'un attibut privé
* \param[in] aucun
* \pre
* \post La fonction retourne l'attribut m_editeur
*/
void Ouvrage::asgEditeur(const std::string& editeur) {
	m_editeur = editeur;
}
/**
* \brief Cette fonction est une fonction de modification d'un attibut privé
* \param[in] aucun
* \pre
* \post La fonction retourne l'attribut m_identifiant
*/
void Ouvrage::asgIdentifiant(const std::string& identifiant) {
	m_identifiant = identifiant;
}
/**
* \brief Cette fonction est une fonction de modification d'un attibut privé
* \param[in] aucun
* \pre
* \post La fonction retourne l'attribut m_titre
*/
void Ouvrage::asgTitre(const std::string& titre) {
	m_titre = titre;
}
/**
* \brief Cette fonction est une fonction de modification d'un attibut privé
* \param[in] aucun
* \pre
* \post La fonction retourne l'attribut m_ville
*/
void Ouvrage::asgVille(const std::string& ville) {
	m_ville = ville;
}
/**
* \brief Cette fonction est une fonction de modification d'un attibut privé
* \param[in] aucun
* \pre
* \post La fonction retourne une chaîne de caractère qui édite les informations d'un objet ouvrage dans un format bien défini
*/
const std::string& Ouvrage::reqOuvrageFormate() const{
	std::ostringstream oss (ostringstream::out);
	std::string ouvrage_formate;
	oss << reqAuteurs() << ". " << reqTitre() << ". " << reqVille() << " : " << reqEditeur() << ", " << reqAnnee() << ". " << reqIdentifiant() << "." <<"\n";
	ouvrage_formate=oss.str();
	return ouvrage_formate;
}

}
