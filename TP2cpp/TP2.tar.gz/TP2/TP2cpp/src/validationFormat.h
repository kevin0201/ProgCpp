
/**
* \file validationFormat.h
* \brief Fichier d'en-tête des fonctions de validations des formats de nom et de code ISSN et ISBN
* \author Kevin BAMOUNI
* \version 1.0
* \date 19/02/2016
*/

#ifndef VALIDATIONFORMAT_H_
#define VALIDATIONFORMAT_H_
using namespace std;

#include <iostream>
#include <string>

namespace util
{

bool validerFormatNom (const std::string& p_nom);
bool validerCodeIssn (const std::string& p_issn);
bool validerCodeIsbn (const std::string& p_isbn);

}

#endif /* VALIDATIONFORMAT_H_ */
