/*
 * BibliographieTesteur.cpp#include<gtest/gtest.h>

 *
 *  Created on: 2016-04-01
 *      Author: etudiant
 */

#include <gtest/gtest.h>
#include "Bibliographie.h"

TEST(BibliographieConstructeur,ConstructeurVide)
{
	Bibliographie uneBibliographie;
}
