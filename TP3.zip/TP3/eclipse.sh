#!/bin/sh
# Exécuter ce fichier dans le même dossier où se trouve .metadata pour lancer eclipse avec le workspace du .metadata. Pour afficher le dossier .metadata, il suffit de cliquer bouton droit et ensuite cliquer sur "Afficher les fichiers cachés" où simplement avec ctrl+h
eclipse -data .
