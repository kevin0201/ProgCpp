var searchData=
[
  ['journal',['Journal',['../class_journal.html',1,'']]]
];
