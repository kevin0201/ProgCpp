var searchData=
[
  ['journal',['Journal',['../class_journal.html#a6197fb7f7820bd0876bec8a5caedf75f',1,'Journal']]]
];
